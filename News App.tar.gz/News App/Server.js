const express = require('express')
const app = express();
const newsRoutes= require('./Routes/newsRoutes')
const dotenv = require('dotenv').config()
const bodyParser = require('body-parser')

const connectDB= require('./Config/newsDB')

//DataBase Connector
connectDB();

//Data sharing in Json format
app.use(bodyParser.json());

// Mounting
app.use('/api/v1',newsRoutes)



// Server status
app.listen(process.env.PORT, ()=>{
    console.log(`Server is Running on ${process.env.PORT}`)
})

