const { response } = require('express');
const News = require('../Model/newsSchema')




//Post request Handling
exports.addNews= async(req,res)=>{


    const body= req.body;
    
    
    try {
            await News.create(body)        

            //Status Code with Response
                res.status(200).json({
                    message: "Add"
            
                })
        
      

    } catch (error) {
        console.log("Error in Creating")
    }

}

//Get Request Handling
exports.displayNews=async(req,res)=>{

    try {
             const news=   await News.find({})     
//Status Code with Response
res.status(302).json({
    "News": news,

})

//Console Message
    console.log('Display All News')
    } catch (error) {
        
    }

}


// Get Request Handling For Category 
exports.category=async(req,res)=>{
    
    const request={
        category: req.params.categoryName
    }
try {
    const news=  await News.find(request)
    
    //Status Code with Response
        res.status(200).json({
        Category : news
    })
       
 // Error Handling in Console   
} catch (error) {
    res.status(400).json({
        'Error': "Bad Request"
    })
    console.log("ERROR")
}
       
    
    
}


//Get Request For Channel
exports.newschannel=async(req,res)=>{

    const request={
        channel: req.params.channelName
    }
try {
    const channel=  await News.find(request)
    // console.log(channel)
    
        res.status(200).json({
        'Channel' : channel
    })
       
    // Error Handling In Console
} catch (error) {
    res.status(400).json({
        'Error': "Bad Request"
    })
    console.log("ERROR")
}
     
}