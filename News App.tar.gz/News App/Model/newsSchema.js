const mongoose= require('mongoose')

//DataBase Schema
const newsSchema = new mongoose.Schema({
  
    title: { 
        type:String,
        required: true,
        min: 5
       
    },
    link: { 
        type:String,
    },
    description:{ 
        type:String,
        required: true

    },
    channel:{ 
        type:String,
        required: true,
        max:20,
    },
    category:{ 
        type:String,
        required: true,
        
    },
    
    date:{ 
        type:Date,
    },
   
    image: { 
        type:String,
    },
    
    source: { 
        type:String,
        required: true
    }
    
    
  });


  //Modeling
  const News= mongoose.model('News', newsSchema);


  module.exports= News;