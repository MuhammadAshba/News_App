
const mongoose = require('mongoose');

const connectDB=()=>{

    // Database Url
    try {
        mongoose.connect(process.env.LOCAL_HOST).then((con)=>{
            console.log(`Database Connected`)
        })
    } 
    //Error Handling
    catch (error) {
        console.log(`Database Error`)
        
    }

}

module.exports= connectDB;