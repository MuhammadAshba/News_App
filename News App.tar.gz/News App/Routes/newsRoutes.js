
const express=require('express')
const router = express.Router()


const { addNews, displayNews, newschannel, category}= require('../Controller/newsController')

//Routes
// Post Request
router.route('/newsAdd').post(addNews)

//Get Request For All News
router.route('/display/news').get(displayNews)

//Get request For Channels
router.route('/display/channel/:channelName').get(newschannel)

//Get Request For Category
router.route('/category/:categoryName').get(category)

module.exports=router;